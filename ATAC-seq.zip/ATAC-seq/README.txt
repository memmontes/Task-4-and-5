Task 4 and 5, on ATAC-seq data processing and analysis

Due to restrictions to enter as root in virtual machine, it was not possible to run docker and R.
Those tasks that requested from those resources, could not be performed on the local server.
The following steps that did not require them have been performed:

- downloading of ATAC-seq data from Encode for sigmoid colon and stomach samples
- building bigbedm bigWik and peak files from the metadata
- downloading of annotation files for GRCh38 from encode
- obtaining md5sum values
- obtaining BED files with the annotation files 
- performing gene annotation
- obtaining expressiones matrixes, along with the 1000 most and the 1000 less expressed genes in the two tissues
- making intersections

The script in .txt (Script Esther Molina.txt) is provided in the ATAC-seq folder, together with the data used and obtained throughout the analyses.

